# CJG

Mid-Term template in preperation for the final integrated.<br>A website based on a randomly given beer company in-class.

## Requirements 

All you need is an up-to-date web browser 
(Chrome/Firefox/Microsoft Edge)

Git is required for local installation.
Download the files and open index.html

## Programs Used

Photoshop<br>
Illustrator<br>
Sublime<br>

## Carter Geerts 2020


